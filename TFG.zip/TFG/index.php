<!DOCTYPE html>
<html>
<head>
<?php
require_once("layouts/main/header.html");
?>
</head>
<body>
<?php
require_once("layouts/main/menu.html");
require_once("layouts/main/body.html");
?>
</body>
</html>