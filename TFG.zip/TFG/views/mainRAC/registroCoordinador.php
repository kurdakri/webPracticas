<!DOCTYPE html>
<html>
<head>
<?php
require_once("../../layouts/mainRAC/header.html");
?>
</head>
<body>
<?php
require_once("../../layouts/mainRAC/menu.html");
require_once("../../layouts/mainRAC/registroCoordinador.html");
?>
</body>
</html>